# example_project

Just an example project for testing rope.


To build this package, run:

```bash
$ python -m build
```

This generates packages in `dist` folder.
