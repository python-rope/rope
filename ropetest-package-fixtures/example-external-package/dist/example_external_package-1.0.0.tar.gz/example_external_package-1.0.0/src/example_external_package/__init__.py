def sample_function():
    pass
